Tinymce/components/EditorImage.vue
